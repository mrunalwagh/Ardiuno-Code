# motion-triggered-image-camera-diy-10
YouTube Video: https://youtu.be/ywCL9zDIrT0
